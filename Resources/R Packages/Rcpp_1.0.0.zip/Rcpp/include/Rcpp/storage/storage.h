#ifndef Rcpp_storage_storage_h
#define Rcpp_storage_storage_h

#include <Rcpp/storage/PreserveStorage.h>
#include <Rcpp/storage/NoProtectStorage.h>

#endif
